This Project is about :

1) Developed an abstractive summarization using Model-Agnostic Meta-Learning(MAML) model that generates meaningful
sentences which summarize with lesstraining data and adapt quickly to new topics.
2) Evaluated its Performance and Accuracy where it performed very well than traditional summarization methods(BERT).
